# Alarm-Clock-android-studio-java
<br>
#git clone https://github.com/Fiszy/Alarm-Clock-android-studio-java.git my_alarm_clock

#ScreenSHOTS

Long press any alarm to edit or delete

![Optional Text](../master/Screenshot/screen1.png)<br>

![Optional Text](../master/Screenshot/screen2.png)<br>
![Optional Text](../master/Screenshot/screen3.png)
![Optional Text](../master/Screenshot/screen4.png)
![Optional Text](../master/Screenshot/screen5.png)

## Contributing

 [Fiszy](https://fiszy.easyprevarsity.com).
